
// Code

// This method gets called by the runtime. Use this method to add services to the container.
public void ConfigureServices(IServiceCollection services)
{

	// This below code has to go into the ConfigureServices() method

	// The following line enables Application Insights telemetry collection.
	services.AddApplicationInsightsTelemetry();
	
	// This code adds other services for your application.
	services.AddRazorPages();
}