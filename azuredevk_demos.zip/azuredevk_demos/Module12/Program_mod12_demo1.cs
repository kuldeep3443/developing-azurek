﻿using System;

using StackExchange.Redis; 
using System.Threading.Tasks;


namespace Rediscache
{
    class Program
    {

        static string connectionString = "<PRIMARY_CONNECTION_STRING>";

       static async Task Main(string[] args) { 
           // The connection to the Azure Cache for Redis is managed by the ConnectionMultiplexer class. 
           using (var cache = ConnectionMultiplexer.Connect(connectionString)) 
           { 
               IDatabase db = cache.GetDatabase(); 
               
               // Snippet below executes a PING to test the server connection 
               var result = await db.ExecuteAsync("ping"); 
               Console.WriteLine($"PING = {result.Type} : {result}"); 
               
               // Call StringSetAsync on the IDatabase object to set the key "test:key" to the value "100" 
               bool setValue = await db.StringSetAsync("mytest:key", "103"); 
               Console.WriteLine($"SET: {setValue}"); 
               
               // StringGetAsync takes the key to retrieve and return the value 
               string getValue = await db.StringGetAsync("mytest:key"); 
               Console.WriteLine($"GET: {getValue}");
            } 
        }
    }
}
